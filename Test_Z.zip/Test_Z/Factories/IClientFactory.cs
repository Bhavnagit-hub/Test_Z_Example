﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Test_Z.Factories
{
    public interface IClientFactory
    {
       IClient GetClient();
     
    }
}
