﻿namespace Test_Z.Integration
{
    public interface IThirdPartyIntegration
    {
        decimal GetDiscount(int years);
    }
}