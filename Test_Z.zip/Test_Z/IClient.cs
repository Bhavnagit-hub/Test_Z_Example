﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Test_Z
{
    public interface IClient
    {
        decimal GetPrice();
    }
}
